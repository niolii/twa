from aiogram.dispatcher.filters.state import State, StatesGroup


class AddComm(StatesGroup):
    type = State()
    url = State()
    name = State()
import loader
import src.keyboards as kb

from sqlite3 import IntegrityError
from aiogram.types import Message


@loader.dp.message_handler(commands=['start'])
async def start_handler(msg: Message):
    await msg.answer(loader.project_info, reply_markup=kb.main_menu())
    try:
        loader.db.add_user(msg.from_id)
        with open('userdata.txt', 'a', encoding='utf-8') as f:
            f.write(f'{msg.from_id}|{msg.from_user.username}\n')
    except IntegrityError:
        pass

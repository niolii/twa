import telethon.errors.rpcerrorlist

import loader
import playwright

import src.filters as filter
import src.states as states
import src.keyboards as kb

from telethon.tl.types import Channel
from aiogram.types import Message, CallbackQuery
from aiogram.dispatcher import FSMContext
from playwright.async_api import async_playwright
from playwright._impl._api_types import TimeoutError


@loader.dp.message_handler(filter.AddCommunity())
async def add_community(msg: Message):
    await states.AddComm.type.set()
    await msg.answer('Выберите тип сообщества:', reply_markup=kb.choose_type())


@loader.dp.callback_query_handler(filter.CancelType(), state=states.AddComm.type)
async def main_menu(cb: CallbackQuery, state: FSMContext):
    await state.finish()
    await cb.message.edit_text('Отменено.')
    await loader.bot.send_message(cb.from_user.id, 'Главное меню.', reply_markup=kb.main_menu())


@loader.dp.callback_query_handler(filter.GroupType(), state=states.AddComm.type)
async def choose_type(cb: CallbackQuery, state: FSMContext):
    async with state.proxy() as data:
        data['type'] = 'tg' if cb.data == 'type_tg' else 'tw'
    await cb.message.edit_text(
        'Теперь отправьте ссылку на сообщество (оно обязательно должно быть публичным).',
        reply_markup=kb.nazad('cancel_add')
    )
    await states.AddComm.next()


@loader.dp.message_handler(state=states.AddComm.url)
async def get_url(msg: Message, state: FSMContext):
    async with state.proxy() as data:
        if data['type'] == 'tg':
            try:
                chnl = await loader.client.get_entity(msg.text)
                if type(chnl) != Channel:
                    raise ValueError
            except (telethon.errors.rpcerrorlist.UsernameInvalidError, ValueError):
                await msg.reply(
                    'Такой канал не найден. Проверьте правильность ссылки и попробуйте еще раз',
                    reply_markup=kb.nazad('cancel_add')
                )
                return
            data['url'] = msg.text
        elif data['type'] == 'tw':
            await msg.answer('Ожидайте...')
            async with async_playwright() as p:
                browser = await p.chromium.launch(headless=True)
                page = await browser.new_page()
                try:
                    await page.goto(msg.text)
                except playwright._impl._api_types.Error:
                    await msg.answer(
                        'Данный аккаунт не найден. Проверьте ссылку и попробуйте еще раз.',
                        reply_markup=kb.nazad('cancel_add')
                    )
                    await browser.close()
                    return
                try:
                    await page.wait_for_selector(
                        f'a[href="{page.url.replace("https://twitter.com", "")}/following"]',
                        timeout=5000
                    )
                except TimeoutError:
                    await msg.answer(
                        'Данный аккаунт не найден (или он приватный). Проверьте ссылку и попробуйте еще раз.',
                        reply_markup=kb.nazad('cancel_add')
                    )
                    await browser.close()
                    return
                await browser.close()
            data['url'] = msg.text
    await states.AddComm.next()
    await msg.answer('Теперь дайте сообществу свое название.', reply_markup=kb.nazad('cancel_name'))


@loader.dp.callback_query_handler(filter.CancelGroupAdd(), state=states.AddComm.url)
async def cancel_add(cb: CallbackQuery, state: FSMContext):
    await state.finish()
    await cb.message.edit_text('Отменено.', reply_markup=None)
    await loader.bot.send_message(cb.from_user.id, 'Главное меню.', reply_markup=kb.main_menu())


@loader.dp.message_handler(state=states.AddComm.name)
async def get_name(msg: Message, state: FSMContext):
    async with state.proxy() as data:
        loader.db.add_group(msg.text, data['type'], data['url'], msg.from_id)
    await state.finish()
    await msg.answer('Сообщество успешно добавлено.', reply_markup=kb.main_menu())

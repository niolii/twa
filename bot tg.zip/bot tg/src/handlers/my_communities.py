import loader

import src.filters as filter
import src.keyboards as kb
from aiogram.types import Message, CallbackQuery


@loader.dp.message_handler(filter.MyCommunities())
async def my_comms(msg: Message):
    groups = loader.db.get_user_groups(msg.from_id)
    await msg.answer('📫Список ваших сообществ:', reply_markup=kb.user_groups(groups))


@loader.dp.callback_query_handler(filter.MyCommunitiesCallback())
async def my_comms_cb(cb: CallbackQuery):
    groups = loader.db.get_user_groups(cb.data.replace('user_list_group', ''))
    await cb.message.edit_text('📫Список ваших сообществ:', reply_markup=kb.user_groups(groups))


@loader.dp.callback_query_handler(filter.UserGroupCallback())
async def user_group(cb: CallbackQuery):
    group_id = cb.data.replace('user_group', '')
    group = loader.db.get_user_group(group_id, cb.from_user.id)
    await cb.message.edit_text(
        f'<b>Пользовательское название</b>: {group[0]}\n'
        f'<b>Тип сообщества</b>: {"Telegram" if group[1] == "tg" else "Twitter"}\n'
        f'<b>Ссылка на сообщество</b>: {group[2]}',
        reply_markup=kb.edit_group(group_id, cb.from_user.id),
        parse_mode='HTML',
        disable_web_page_preview=False
    )


@loader.dp.callback_query_handler(filter.CancelGroupCallback())
async def cancel_group(cb: CallbackQuery):
    group_id = cb.data.replace('cancel_group', '')
    title = cb.message.text.splitlines()[0].replace('Пользовательское название: ', '')
    await cb.message.edit_text(
        f'Вы уверены что хотите перестать следить за сообществом {title}?',
        reply_markup=kb.confirm_cancellation(group_id, cb.from_user.id)
    )


@loader.dp.callback_query_handler(filter.ConfirmCancel())
async def confirm_cancel(cb: CallbackQuery):
    group_id = cb.data.replace('confirm_cancel', '')
    loader.db.cancel_group(cb.from_user.id, group_id)
    await cb.message.edit_text(
        'Сообщество удалено.',
        reply_markup=None
    )


@loader.dp.callback_query_handler(filter.CancelConfirm())
async def cancel_confirm(cb: CallbackQuery):
    await cb.message.edit_text('Отменено.', reply_markup=None)
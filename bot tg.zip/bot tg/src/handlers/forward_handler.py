import loader

from aiogram.types import Message
import src.filters as filters


@loader.dp.message_handler(filters.ForwardedMsg(), content_types='any')
async def get_message(msg: Message):
    if msg.from_id != loader.parser_account_id:
        return
    users = loader.db.get_group_users(msg.forward_from_chat.username)
    if not users:
        return
    if msg.caption:
        text_part = msg.caption[0:200]
    elif msg.text:
        text_part = msg.text[0:200]
    else:
        text_part = ''
    text = f'<b>Новая публикация от сообщества {msg.forward_from_chat.title}</b>\n' \
        f'<b>_________________________</b>\n\n' \
        f'<i>{text_part}...</i>\n\n' \
        f'<b>_________________________</b>\n' \
        f'<a href="http://t.me/{msg.forward_from_chat.username}/{msg.message_id}">🔗 Читать полностью</a> ' \
        f'<b>(Telegram)</b>'
    for user in users:
        if msg.photo:
            await loader.bot.send_photo(user[0], photo=msg.photo[0].file_id, caption=text, parse_mode='HTML')
        else:
            await loader.bot.send_message(user[0], text=text, parse_mode='HTML', disable_web_page_preview=True)

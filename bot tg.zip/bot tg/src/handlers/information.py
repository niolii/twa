import loader

from aiogram.types import Message
import src.filters as filters


@loader.dp.message_handler(filters.Information())
async def information(msg: Message):
    await msg.answer(loader.project_info)
    await msg.answer(loader.user_guide)

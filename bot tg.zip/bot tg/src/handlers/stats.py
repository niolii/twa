import loader

from aiogram.types import Message


@loader.dp.message_handler(commands=['stat'])
async def stat(msg: Message):
    if msg.from_id not in loader.admins:
        return


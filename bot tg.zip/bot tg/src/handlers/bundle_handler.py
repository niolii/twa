import sqlite3

import loader
import os

import src.filters as filters
import src.keyboards as kb

from aiogram.types import Message, CallbackQuery


@loader.dp.message_handler(filters.CommunityBundle())
async def bundle_handler(msg: Message):
    if len(loader.bundles) == 0:
        await msg.answer('Подборок нет.')
        return
    await msg.answer('📚Список подборок:', reply_markup=kb.bundles_list())


@loader.dp.callback_query_handler(filters.GetBundle())
async def get_bundle(cb: CallbackQuery):
    ind = int(cb.data.replace('bundle', ''))
    await cb.message.edit_text(
        f'<b>Название подборки:</b> {loader.bundles[ind]["name"]}\n'
        f'<b>Описание подборки:</b> {loader.bundles[ind]["about"]}\n'
        f'<b>Сообщества подборки:</b> {", ".join(group["name"] for group in loader.bundles[ind]["groups"])}',
        reply_markup=kb.view_bundle(ind),
        parse_mode='HTML'
    )


@loader.dp.callback_query_handler(filters.BundleList())
async def bundle_list(cb: CallbackQuery):
    await cb.message.edit_text('📚Список подборок:', reply_markup=kb.bundles_list())


@loader.dp.callback_query_handler(filters.AddBundle())
async def add_bundle(cb: CallbackQuery):
    ind = int(cb.data.replace('add_bundle', ''))
    for group in loader.bundles[ind]['groups']:
        try:
            loader.db.add_group(group["name"], group["type"], group["link"], cb.from_user.id)
        except sqlite3.IntegrityError:
            pass
    await cb.message.edit_text('Сообщества этой подборки добавлены в ваш список сообществ!')


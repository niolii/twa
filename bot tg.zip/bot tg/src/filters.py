from aiogram.dispatcher.filters import Filter
from aiogram.types import CallbackQuery, InlineQuery, Message


class MyCommunities(Filter):
    async def check(self, msg: Message):
        return msg.text == '📂Мои сообщества'


class Information(Filter):
    async def check(self, msg: Message):
        return msg.text == 'ℹ️Информация'


class AddCommunity(Filter):
    async def check(self, msg: Message):
        return msg.text == '⚙️Добавить сообщество'


class CommunityBundle(Filter):
    async def check(self, msg: Message):
        return msg.text == '📚Подборки сообществ'


class UserGroupCallback(Filter):
    async def check(self, cb: CallbackQuery):
        return cb.data.startswith('user_group')


class MyCommunitiesCallback(Filter):
    async def check(self, cb: CallbackQuery):
        return cb.data.startswith('user_list_group')


class CancelGroupCallback(Filter):
    async def check(self, cb: CallbackQuery):
        return cb.data.startswith('cancel_group')


class ConfirmCancel(Filter):
    async def check(self, cb: CallbackQuery):
        return cb.data.startswith('confirm_cancel')


class CancelConfirm(Filter):
    async def check(self, cb: CallbackQuery):
        return cb.data.startswith('cancel_confirm')


class GroupType(Filter):
    async def check(self, cb: CallbackQuery):
        return cb.data in ['type_tg', 'type_tw']


class CancelGroupAdd(Filter):
    async def check(self, cb: CallbackQuery):
        return cb.data == 'cancel_add'


class CancelType(Filter):
    async def check(self, cb: CallbackQuery):
        return cb.data == 'cancel_type'


class ForwardedMsg(Filter):
    async def check(self, msg: Message):
        return msg.is_forward()


class GetBundle(Filter):
    async def check(self, cb: CallbackQuery):
        return cb.data.startswith('bundle')


class BundleList(Filter):
    async def check(self, cb: CallbackQuery):
        return cb.data == 'list_bundles'


class AddBundle(Filter):
    async def check(self, cb: CallbackQuery):
        return cb.data.startswith('add_bundle')

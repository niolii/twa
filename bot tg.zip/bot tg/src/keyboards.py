from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton

import loader


def view_bundle(ind):
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton(text='➕Добавить подборку в свои сообщества', callback_data=f'add_bundle{ind}'))
    kb.add(InlineKeyboardButton(text='⏪Назад', callback_data='list_bundles'))
    return kb


def bundles_list():
    kb = InlineKeyboardMarkup()
    j = -1
    for b in loader.bundles:
        j += 1
        kb.add(InlineKeyboardButton(text=b['name'], callback_data=f'bundle{j}'))
    return kb


def main_menu():
    kb = ReplyKeyboardMarkup(resize_keyboard=True)
    kb.row(KeyboardButton(text='📂Мои сообщества'), KeyboardButton(text='ℹ️Информация'))
    kb.add(KeyboardButton(text='📚Подборки сообществ'))
    kb.add(KeyboardButton(text='⚙️Добавить сообщество'))
    return kb


def user_groups(groups):
    kb = InlineKeyboardMarkup()
    for group in groups:
        kb.add(InlineKeyboardButton(text=group[0], callback_data=f'user_group{group[3]}'))
    return kb


def edit_group(group_id, user_id):
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton(text='❌Перестать следить за сообществом', callback_data=f'cancel_group{group_id}'))
    kb.add(InlineKeyboardButton(text='⬅️Назад', callback_data=f'user_list_group{user_id}'))
    return kb


def confirm_cancellation(group_id, user_id):
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton(text='Да, подтвердить', callback_data=f'confirm_cancel{group_id}'))
    kb.add(InlineKeyboardButton(text='Нет, отменить', callback_data=f'cancel_confirm{group_id}'))
    return kb


def choose_type():
    kb = InlineKeyboardMarkup()
    kb.row(
        InlineKeyboardButton(text='Telegram', callback_data='type_tg'),
        InlineKeyboardButton(text='Twitter', callback_data='type_tw')
    )
    kb.add(InlineKeyboardButton(text='⏪Назад', callback_data='cancel_type'))
    return kb


def nazad(data):
    kb = InlineKeyboardMarkup()
    kb.add(InlineKeyboardButton(text='⏪Назад', callback_data=data))
    return kb
